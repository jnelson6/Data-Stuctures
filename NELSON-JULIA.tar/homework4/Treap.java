package homework4;

import java.util.Random;

/**
 * A class to represent a treap, that is, a BST with node placement
 * randomized by probabilistic heap-like priorities
 * @author Julia Nelson I pledge my honor that I have abided by the Stevens Honor System
 */
public class Treap<E extends Comparable<E>> extends BinarySearchTree<E> {
    
	protected static class Node<E> {
		public E data; // key for the search
		public int priority; // random heap priority
		public Node<E> left;
		public Node<E> right;


		/** Creates a new node with the given data and priority. The
		 *  pointers to child nodes are null. Throw exceptions if data
		 *  is null. 
		 */
		public Node(E data, int priority) {
			if (data == null){
				throw new IllegalArgumentException("Node Data cannot be null"); 
			}
	    		this.data = data;
	    		this.priority = priority;
	    		this.right = null;
	    		this.left = null;
	    	}
	
		public Node<E> rotateRight() { 
	    			Node<E> newroot = this.left;
	    			this.left = newroot.right;
	    			newroot.right = this;
	    			return newroot;	 
	    		}
		 


		public Node<E> rotateLeft() {	
				Node<E> newroot = this.right;
	    			this.right = newroot.left;
	    			newroot.left = this;
	    			return newroot; 
	    	}   
		
		@Override
        public String toString(){
            return "(key=" +this.data+", priority=" +this.priority+ ")";
        }
	}
	


    private Random priorityGenerator;
    private Node<E> root;

    /** Create an empty treap. Initialize { priorityGenerator}
     * using { new Random()}. 
     */
    
    public Treap(){
    	this.priorityGenerator = new Random();
    	this.root = null;			

    }


    /** Create an empty treap and initializes {
     * priorityGenerator} using { new Random(seed)}
     */
    public Treap(long seed) {
		priorityGenerator = new Random(seed);
		root = null;			
    }


    protected boolean addReturn;
    
	/* generate a random
	* priority using priorityGenerator and delegate to private Node<E> add
	*/
    public boolean add(E key){
    	if(key == null) {
    			throw new NullPointerException("key cant be null");
    		}
    	int priority = priorityGenerator.nextInt();
		root = add(root, key, priority);
		return addReturn;
    }

    /* returns the t/f needed by the boolean add method and uses addReturn param*/
    private Node<E> add(Node<E> localroot, E key, int priority){
    	if (localroot == null){ // key is not in the tree; insert it.
           	addReturn = true;
           	return new Node<E>(key, priority);
       	}
    	else if (key.compareTo(localroot.data) == 0) { 	// key is equal to localroot.data
    			addReturn = false;
    			
        }
    		
    	else if (key.compareTo(localroot.data) < 0) { 			// key is less than localroot.data
           	localroot.left = add(localroot.left, key, priority);		
           	if (localroot.priority > localroot.left.priority){  		
           		localroot = localroot.rotateRight();
           	}
           	addReturn = true;
        }
    	else if (key.compareTo(localroot.data) > 0) {	// key is greater than localroot.data
            localroot.right = add(localroot.right, key, priority);	
			if (localroot.priority > localroot.right.priority) { 		
           		localroot = localroot.rotateLeft();
           	}
			addReturn = true;
        }
        return localroot;

	}

	/*helper add method for implementing in test cases*/
	public boolean add(E key, int priority){
		if (key == null){
			throw new NullPointerException("the key can't be null");
		}
		if (find(key) == null) {
			root = add(root, key, priority);
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/*
	 * deletes  node from  treap
	 * @param key,  key of the node we need to delete
	 * @return, returns curr.data if successfully deleted, null if not found in treap
	 */
	
	public E delete(E key) {
		
			Node<E> curr;
			curr = root;		//root at the top of the treap
			Node<E> supR;
			supR= null;			//there is no node above the main root
			
			while (curr != null){
					int result = key.compareTo(curr.data);
					if(result > 0) {
						supR = curr;
						curr = curr.right;
					}
					else if(result < 0) {
						supR = curr;
						curr = curr.left;	
					}
					else{
						if(key.compareTo(this.root.data) == 0) {
							if(this.root.left == null){
								this.root = this.root.right;
								return curr.data;
							}
							else if (this.root.right == null){
								this.root = this.root.left;
								return curr.data;
							}
							
							if(this.root.right.priority > this.root.left.priority){
								this.root = this.root.rotateLeft();
								supR = root;
							}
							else if (this.root.right.priority < this.root.left.priority){
								this.root = this.root.rotateRight();	
								supR = root;
								}
						}
						
						else if (curr.left != null && curr.right != null) {
							if(curr.right.priority < curr.left.priority){
								if(supR.left == curr) {
									supR.left = curr.rotateRight();
									supR = supR.left;
									}
								else{
									supR.right = curr.rotateRight();
									supR = supR.right;
								}
							}
							else if(curr.right.priority > curr.left.priority) {
								if(supR.right == curr){
									supR.right = curr.rotateLeft();
									supR = supR.right;
									
								}
								else if(supR.left == curr) {
									supR.left = curr.rotateLeft();
									supR = supR.left;
									}
								
								}
						}
						
						else if(curr.right == null && curr.left == null){
							result = supR.data.compareTo(curr.data);
							if(result < 0){
								supR.right = null;
								return curr.data;
							}
							else if (result > 0){
								supR.left = null;
								return curr.data;
							}
						}
						
						else if (curr.right != null && curr.left == null) {
							if(supR.right == curr){
								supR.right = curr.rotateLeft();
								supR = supR.right;
							}
							else if(supR.left == curr){
								supR.left = curr.rotateLeft();
								supR = supR.left;
							}
							
						}
						
						else if (curr.right == null && curr.left != null){
							if(supR.left == curr){
								supR.left = curr.rotateRight();
								supR = supR.left;
							}
							else if(supR.right == curr){
								supR.right = curr.rotateRight();
								supR = supR.right;
							}
						}
					}	
				}
				if (find(key) == null) {		
					return curr.data;
				}
				return curr.data;
			}


	/* Finds a node with the given key in the treap rooted at
	* root and returns its key if found and null otherwise
	*/	
    private E find(Node<E> root, E key) { 
    	if (root == null) {
    		return null;
    	}
    	int result = key.compareTo(root.data);
        if (result == 0 ){
        	return root.data;
        }
        else if (result < 0) {
        	return find(root.left, key);
        }
        else{			// if (result > 0) 
        	return find(root.right, key);
        }    			
    }
    
    /* Finds a node with the given key in the treap and returns its key if
	* it finds it and null otherwise.*/
    public E find(E key) {
    	if (key == null) {
    		throw new NullPointerException("the key can't be null");
    	}
    	return find(root, key);
    }

    /* toString method from class
    * helper function preOrderTraverse
    * @returns the new toSring
    */
    public String toString(){
    	StringBuilder sb = new StringBuilder();
    	preOrderTraverse(root, 1, sb);
    	return sb.toString();
    }

    private void preOrderTraverse(Node<E> node, int depth,StringBuilder sb){
    	for (int i = 1; i < depth; i++){
    		sb.append("  ");
    	}
    	if (node == null){
    		sb.append("null\n");
    	} 
    	else{
    		sb.append(node.toString());
    		sb.append("\n");
    		preOrderTraverse(node.left, depth + 1, sb);
    		preOrderTraverse(node.right, depth + 1, sb);
    	}
    }

   


    }

