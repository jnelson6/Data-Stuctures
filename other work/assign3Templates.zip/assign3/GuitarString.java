/*
 * GuitarString.java
 *
 */

package assign3;
import java.lang.Math;

public class GuitarString extends InstString{

    public GuitarString(){};
   
 
    public GuitarString(double frequency) {	

    }

    public GuitarString(double[] init) {

    }
   
    public void pluck() {	
	
    }
   
    public void tic() {
	
    }

}
