/*
 * Instrument.java
 */
package assign3;

public abstract class Instrument {
    
    protected  InstString[] strings;
    
    public void playNote(int i){

    }

    public  double ringNotes(){

    }

}
