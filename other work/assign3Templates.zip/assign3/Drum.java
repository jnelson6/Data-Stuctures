/*
 * Drum.java
 */
package assign3;

public class Drum extends Instrument{

    public Drum(int numNotes){

    }		    
}
