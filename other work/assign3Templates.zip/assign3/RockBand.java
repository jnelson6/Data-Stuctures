/*
 * RockBand.java
 *
 */

package assign3;
import cos126.StdDraw;
import cos126.StdAudio;
import java.io.IOException;
import java.util.ArrayList;

public class RockBand {


    String guitarBassKeyboard ="`1234567890-=qwertyuiop[]\\asdfghjkl;'";
    String pianoKeyboard = "~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:\"";
    String drumKeyboard = "ZXCVBNM<>?zxcvbnm,.";
  
    public static void main(String[] args) {

    }
}
