/*
 * Bass.java
 */
package assign3;

public class Bass extends Instrument{


    public Bass(int numNotes){

    }		    
}
