/*
 * DrumString.java
 *
 */

package assign3;
import java.lang.Math;


public class DrumString extends InstString{

   
    public DrumString(double frequency) {

    }

    public DrumString(double[] init) {

    }

    public void pluck() {

    }
    
    public void tic() {
	
    }
}
