/*
 * Guitar.java
 */
package assign3;

public class Guitar extends Instrument{


    public Guitar(int numNotes){

    }		    
}
