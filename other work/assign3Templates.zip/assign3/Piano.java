/*
 * Piano.java
 */

package assign3;


public class Piano extends Instrument{

    private static InstString[][] pStrings; //2D array of strings
    
    public Piano(int numNotes){

    }
  
    public void playNote(int index){
	 
    }
    
    public double ringNotes(){

    }
			    

}
