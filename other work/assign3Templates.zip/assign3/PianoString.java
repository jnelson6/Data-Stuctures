/*
 * PianoString.java
 *
 */

package assign3;
import java.lang.Math;

public class PianoString extends InstString {
  
    public PianoString(double frequency) {

    }

    public PianoString(double[] init) {

    }
   
    public void pluck() {

    }
   
    public void tic() {	

    }

}
